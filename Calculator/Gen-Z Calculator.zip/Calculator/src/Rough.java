import javax.swing.ImageIcon;
import javax.swing.JFrame;

import GenZ.main.StrToHcfLcm;

public class Rough {

    ImageIcon img = new ImageIcon("/Images/add");


    Rough(){
        JFrame form = new JFrame();
        
        form.setVisible(true);
        form.setSize(420,420);
        form.setTitle("Danishan");
        ImageIcon image = new ImageIcon("/Images/add.png");
        form.setIconImage(image.getImage());
        form.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // form.getContentPane().setBackground(Color.DARK_GRAY);

    }
    public static void main(String[] args) {
        // Rough A = new Rough();
        System.out.println("A.resultNumFun()");
        StrToHcfLcm A = new StrToHcfLcm();
        StrToHcfLcm B = new StrToHcfLcm();
        // A.convertStrIntoInfix("10,20,30");
        long A1= A.StrToHCF_Fun("150,20,30");
        
        System.out.println(A1);
        long A2= B.StrToLCM_Fun("90,48");
        System.out.println(A2);

       

        // yes.
        // for (int i = 0; i < A.topInfix; i++)

        // A.infixToNumFun();
        // for (int i = 0; i <= A.topPostfix; i++)
        //     System.out.println(A.postfixStackArr[i]);
    }
}
