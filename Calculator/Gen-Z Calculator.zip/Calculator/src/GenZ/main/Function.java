package GenZ.main;

public class Function {

    void Apps()
    {
        
    }
}
